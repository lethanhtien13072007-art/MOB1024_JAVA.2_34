/**
 * 
 */
/**
 * 
 */
module Lab1 {
}